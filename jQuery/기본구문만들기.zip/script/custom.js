$("p").css({ display: "none" });

//보이기버튼 누르면 보인다
$(".show-btn").click(function () {
    $("p").css({ display: "block" });
});

//감추기버튼 누르면 감춘다
$(".hide-btn").click(function () {
    $("p").css({ display: "none" });
});

$('선택자').click(function(){
    
})
